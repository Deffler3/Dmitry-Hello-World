﻿using System;
using System.Collections.Generic;
using System.Linq;
using CH.CodingExercise.Api.MessageWriters;

namespace CH.CodingExercise.Api
{
    public class MessageWriterFactory
    {
        public CompositeMessageWriter Create(List<MessageWriterType> messageWriterTypes)
        {
            var messageWriters = messageWriterTypes.Select(Create).ToList();
            return new CompositeMessageWriter(messageWriters);
        }

        public IMessageWriter Create(MessageWriterType messageWriterType)
        {
            switch (messageWriterType)
            {
                case MessageWriterType.Console:
                    return new ConsoleMessageWriter();
                default:
                    throw new NotImplementedException($"Unknown message writer type {messageWriterType}");
            }
        }
    }
}