﻿using System.Collections.Generic;

namespace CH.CodingExercise.Api.MessageWriters
{
    public class CompositeMessageWriter : IMessageWriter
    {
        private readonly List<IMessageWriter> _writers;

        public CompositeMessageWriter(List<IMessageWriter> messageWriters)
        {
            _writers = messageWriters;
        }

        public void Write(string message)
        {
            _writers.ForEach(w => w.Write(message));
        }
    }
}