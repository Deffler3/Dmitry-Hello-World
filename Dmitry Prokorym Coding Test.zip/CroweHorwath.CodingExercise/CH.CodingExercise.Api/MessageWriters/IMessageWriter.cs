namespace CH.CodingExercise.Api.MessageWriters
{
    public interface IMessageWriter
    {
        void Write(string message);
    }
}