﻿namespace CH.CodingExercise.Api
{
    public enum MessageWriterType
    {
        Console = 1
    }
}