﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using CH.CodingExercise.Api;

namespace CH.CodingExercise.Console
{
    public static class ApplicationConfiguration
    {
        public static List<MessageWriterType> MessageWriterTypes
        {
            get
            {
                var configValues = ConfigurationManager.AppSettings["messageWriterTypes"].Split(new[] { "," },
                    StringSplitOptions.RemoveEmptyEntries);

                return
                    configValues.Select(v => (MessageWriterType)Enum.Parse(typeof(MessageWriterType), v, true))
                        .ToList();
            }
        }
    }
}