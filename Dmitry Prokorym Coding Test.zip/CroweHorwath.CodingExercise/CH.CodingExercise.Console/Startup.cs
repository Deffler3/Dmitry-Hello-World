﻿using CH.CodingExercise.Api;

namespace CH.CodingExercise.Console
{
    public class Startup
    {
        public static void Main()
        {
            var factory = new MessageWriterFactory();

            // it's possible to instantiate only one MessageWriter using the factory,
            // but I want to show that API is extendable and allows to write messages into multiple 
            // destinations simultaneously
            var compositeWriter = factory.Create(ApplicationConfiguration.MessageWriterTypes);
            compositeWriter.Write("Hello, world!");
            compositeWriter.Write("Press Enter to close the window");

            System.Console.ReadLine();
        }
    }
}
