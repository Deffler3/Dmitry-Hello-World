using CH.CodingExercise.Api.MessageWriters;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CH.CodingExercise.UnitTests
{
    [TestClass]
    public class ConsoleMessageWriterTests
    {
        [TestMethod]
        public void WriteMessageTest()
        {
            var message = "hello";
            var writer = new ConsoleMessageWriter();
            writer.Write(message);
        }
    }
}