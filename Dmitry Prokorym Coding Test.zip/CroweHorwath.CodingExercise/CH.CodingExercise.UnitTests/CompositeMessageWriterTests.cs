﻿using System.Collections.Generic;
using CH.CodingExercise.Api.MessageWriters;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace CH.CodingExercise.UnitTests
{
    [TestClass]
    public class CompositeMessageWriterTests
    {
        [TestMethod]
        public void CallsAllWritersTest()
        {
            var writer1 = new Mock<IMessageWriter>();
            var writer2 = new Mock<IMessageWriter>();

            var writer = new CompositeMessageWriter(new List<IMessageWriter> {writer1.Object, writer2.Object});

            const string message = "hello";
            writer.Write(message);

            writer1.Verify(x => x.Write(message), Times.Once);
            writer2.Verify(x => x.Write(message), Times.Once);
        }
    }
}