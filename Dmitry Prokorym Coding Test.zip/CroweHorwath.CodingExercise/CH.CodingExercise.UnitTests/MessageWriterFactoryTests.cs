﻿using System.Collections.Generic;
using CH.CodingExercise.Api;
using CH.CodingExercise.Api.MessageWriters;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CH.CodingExercise.UnitTests
{
    [TestClass]
    public class MessageWriterFactoryTests
    {
        private MessageWriterFactory _messageWriterFactory;

        [TestInitialize]
        public void Initialize()
        {
            _messageWriterFactory = new MessageWriterFactory();
        }

        [TestMethod]
        public void CreateConsoleMessageWriterTest()
        {
            var messageWriterType = MessageWriterType.Console;
            var writer = _messageWriterFactory.Create(messageWriterType);

            Assert.IsInstanceOfType(writer, typeof(ConsoleMessageWriter));
        }

        [TestMethod]
        public void CreateCompositeWriterTest()
        {
            var writerTypes = new List<MessageWriterType> {MessageWriterType.Console};
            var compositeMessageWriter = _messageWriterFactory.Create(writerTypes);

            Assert.IsNotNull(compositeMessageWriter);
        }
    }
}